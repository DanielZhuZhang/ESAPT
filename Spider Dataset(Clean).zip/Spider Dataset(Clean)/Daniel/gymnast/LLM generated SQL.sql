CREATE TABLE people (
    People_ID INT,
    Height NUMERIC,
    Age INT,
    Hometown TEXT,
    Name TEXT,
    PRIMARY KEY(People_ID)
);

CREATE TABLE gymnast (
    People_ID INT NOT NULL,
    Gymnast_ID INT NOT NULL,
    Vault_Points NUMERIC,
    Rings_Points NUMERIC,
    Pommel_Horse_Points NUMERIC,
    Parallel_Bars_Points NUMERIC,
    Total_Points NUMERIC,
    Horizontal_Bar_Points NUMERIC,
    Floor_Exercise_Points NUMERIC,
    PRIMARY KEY(People_ID, Gymnast_ID),
    FOREIGN KEY(People_ID) REFERENCES people(People_ID) ON DELETE CASCADE
);