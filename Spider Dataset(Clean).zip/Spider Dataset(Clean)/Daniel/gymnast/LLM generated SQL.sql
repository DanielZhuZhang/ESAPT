CREATE TABLE people (
    People_ID INTEGER,
    Height NUMERIC,
    Age INTEGER,
    Hometown VARCHAR(255),
    Name VARCHAR(255),
    PRIMARY KEY (People_ID)
);

CREATE TABLE gymnast (
    People_ID INTEGER NOT NULL,
    Gymnast_ID INTEGER NOT NULL,
    Vault_Points NUMERIC,
    Rings_Points NUMERIC,
    Pommel_Horse_Points NUMERIC,
    Parallel_Bars_Points NUMERIC,
    Total_Points NUMERIC,
    Horizontal_Bar_Points NUMERIC,
    Floor_Exercise_Points NUMERIC,
    PRIMARY KEY (People_ID, Gymnast_ID),
    FOREIGN KEY (People_ID) REFERENCES people (People_ID) ON DELETE CASCADE
);