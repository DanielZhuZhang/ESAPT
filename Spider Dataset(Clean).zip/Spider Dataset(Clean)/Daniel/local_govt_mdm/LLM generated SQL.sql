CREATE TABLE CMI_Cross_References (
    cmi_cross_ref_id TEXT NOT NULL,
    source_system_code TEXT NOT NULL,
    PRIMARY KEY (cmi_cross_ref_id, source_system_code)
);

CREATE TABLE Electoral_Register (
    electoral_register_id TEXT NOT NULL,
    cmi_cross_ref_id TEXT,
    source_system_code TEXT,
    PRIMARY KEY (electoral_register_id),
    FOREIGN KEY (cmi_cross_ref_id, source_system_code) REFERENCES CMI_Cross_References (cmi_cross_ref_id, source_system_code)
);

CREATE TABLE Customer_Master_Index (
    master_customer_id TEXT NOT NULL,
    cmi_details TEXT,
    cmi_cross_ref_id TEXT,
    source_system_code TEXT,
    PRIMARY KEY (master_customer_id),
    FOREIGN KEY (cmi_cross_ref_id, source_system_code) REFERENCES CMI_Cross_References (cmi_cross_ref_id, source_system_code)
);

CREATE TABLE Business_Rates (
    business_rates_id TEXT NOT NULL,
    cmi_cross_ref_id TEXT,
    source_system_code TEXT,
    PRIMARY KEY (business_rates_id),
    FOREIGN KEY (cmi_cross_ref_id, source_system_code) REFERENCES CMI_Cross_References (cmi_cross_ref_id, source_system_code)
);

CREATE TABLE Benefits_Overpayments (
    council_tax_id TEXT NOT NULL,
    cmi_cross_ref_id TEXT,
    source_system_code TEXT,
    PRIMARY KEY (council_tax_id),
    FOREIGN KEY (cmi_cross_ref_id, source_system_code) REFERENCES CMI_Cross_References (cmi_cross_ref_id, source_system_code)
);

CREATE TABLE Council_Tax (
    council_tax_id TEXT NOT NULL,
    cmi_cross_ref_id TEXT,
    source_system_code TEXT,
    PRIMARY KEY (council_tax_id),
    FOREIGN KEY (cmi_cross_ref_id, source_system_code) REFERENCES CMI_Cross_References (cmi_cross_ref_id, source_system_code)
);

CREATE TABLE Rent_Arrears (
    council_tax_id TEXT NOT NULL,
    cmi_cross_ref_id TEXT,
    source_system_code TEXT,
    PRIMARY KEY (council_tax_id),
    FOREIGN KEY (cmi_cross_ref_id, source_system_code) REFERENCES CMI_Cross_References (cmi_cross_ref_id, source_system_code)
);

CREATE TABLE Parking_Fines (
    council_tax_id TEXT NOT NULL,
    cmi_cross_ref_id TEXT,
    source_system_code TEXT,
    PRIMARY KEY (council_tax_id),
    FOREIGN KEY (cmi_cross_ref_id, source_system_code) REFERENCES CMI_Cross_References (cmi_cross_ref_id, source_system_code)
);