CREATE TABLE buildings (
    id INT NOT NULL,
    name VARCHAR(255),
    City VARCHAR(255),
    Status VARCHAR(255),
    Height INT,
    Stories INT,
    PRIMARY KEY (id)
);

CREATE TABLE Companies (
    id INT NOT NULL,
    name VARCHAR(255),
    Industry VARCHAR(255),
    Profits_billion NUMERIC(10, 2),
    Headquarters VARCHAR(255),
    Sales_billion NUMERIC(10, 2),
    Assets_billion NUMERIC(10, 2),
    Market_Value_billion NUMERIC(10, 2),
    PRIMARY KEY (id)
);

CREATE TABLE Office_locations (
    buildings_id INT NOT NULL,
    companies_id INT NOT NULL,
    move_in_year INT NOT NULL,
    PRIMARY KEY (buildings_id, companies_id, move_in_year),
    FOREIGN KEY (buildings_id) REFERENCES buildings (id) ON DELETE CASCADE,
    FOREIGN KEY (companies_id) REFERENCES Companies (id) ON DELETE CASCADE
);