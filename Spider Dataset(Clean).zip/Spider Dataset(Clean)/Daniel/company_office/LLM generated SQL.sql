CREATE TABLE buildings (
    id INT,
    name VARCHAR(255),
    City VARCHAR(255),
    Status VARCHAR(255),
    Height INT,
    Stories INT,
    PRIMARY KEY (id)
);

CREATE TABLE Companies (
    id INT,
    name VARCHAR(255),
    Industry VARCHAR(255),
    Profits_billion DECIMAL(18, 2),
    Headquarters VARCHAR(255),
    Sales_billion DECIMAL(18, 2),
    Assets_billion DECIMAL(18, 2),
    Market_Value_billion DECIMAL(18, 2),
    PRIMARY KEY (id)
);

CREATE TABLE Office_locations (
    move_in_year INT,
    buildings_id INT NOT NULL,
    companies_id INT,
    PRIMARY KEY (buildings_id, move_in_year),
    FOREIGN KEY (buildings_id) REFERENCES buildings(id) ON DELETE CASCADE,
    FOREIGN KEY (companies_id) REFERENCES Companies(id)
);