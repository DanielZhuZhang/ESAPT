CREATE TABLE people (
    People_ID INTEGER,
    Name VARCHAR(255),
    Birth_Place VARCHAR(255),
    Birth_Date DATE,
    Height NUMERIC,
    Weight NUMERIC,
    PRIMARY KEY (People_ID)
);

CREATE TABLE body_builder (
    Body_Builder_ID INTEGER,
    Snatch NUMERIC,
    Clean_Jerk NUMERIC,
    Total NUMERIC,
    People_ID INTEGER,
    PRIMARY KEY (Body_Builder_ID),
    FOREIGN KEY (People_ID) REFERENCES people (People_ID)
);