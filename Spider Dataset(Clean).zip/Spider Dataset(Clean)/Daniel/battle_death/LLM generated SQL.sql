CREATE TABLE battle (
    id INTEGER,
    name TEXT,
    date DATE,
    bulgarian_commander TEXT,
    latin_commander TEXT,
    result TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE ship (
    id INTEGER,
    name TEXT,
    ship_type TEXT,
    tonnage INTEGER,
    location TEXT,
    disposition_of_ship TEXT,
    battle_id INTEGER,
    PRIMARY KEY (id),
    FOREIGN KEY (battle_id) REFERENCES battle (id)
);

CREATE TABLE death (
    id INTEGER,
    note TEXT,
    killed INTEGER,
    injured INTEGER,
    ship_id INTEGER,
    PRIMARY KEY (id),
    FOREIGN KEY (ship_id) REFERENCES ship (id)
);