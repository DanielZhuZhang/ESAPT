-- SQL After Applying Step 5
CREATE TABLE battle (
    id INTEGER,
    name VARCHAR(255),
    date DATE,
    bulgarian_commander VARCHAR(255),
    result VARCHAR(255),
    latin_commander VARCHAR(255),
    PRIMARY KEY (id)
);

CREATE TABLE ship (
    id INTEGER,
    ship_type VARCHAR(255),
    disposition_of_ship VARCHAR(255),
    location VARCHAR(255),
    name VARCHAR(255),
    tonnage INTEGER,
    battle_id INTEGER,
    PRIMARY KEY (id),
    FOREIGN KEY (battle_id) REFERENCES battle (id)
);

CREATE TABLE death (
    id INTEGER,
    killed INTEGER,
    note TEXT,
    injured INTEGER,
    ship_id INTEGER,
    PRIMARY KEY (id),
    FOREIGN KEY (ship_id) REFERENCES ship (id)
);