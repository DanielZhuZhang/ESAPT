CREATE TABLE Customers (
    Customer_ID INT,
    Customer_name VARCHAR(255),
    PRIMARY KEY (Customer_ID)
);

CREATE TABLE Services (
    Service_ID INT,
    Service_name VARCHAR(255),
    PRIMARY KEY (Service_ID)
);

CREATE TABLE Available_Policies (
    Policy_ID INT,
    policy_type_code VARCHAR(255),
    Customer_Phone VARCHAR(255),
    PRIMARY KEY (Policy_ID)
);

CREATE TABLE First_Notification_of_Loss (
    FNOL_ID INT,
    PRIMARY KEY (FNOL_ID)
);

CREATE TABLE Claims (
    Claim_ID INT,
    Effective_Date DATE,
    PRIMARY KEY (Claim_ID)
);

CREATE TABLE Settlements (
    Settlement_ID INT,
    Settlement_Amount NUMERIC(10, 2),
    Effective_Date DATE,
    PRIMARY KEY (Settlement_ID)
);

-- Associative Entity: Customers_Policies
CREATE TABLE Customers_Policies (
    Customer_ID INT,
    Policy_ID INT,
    Date_Opened DATE,
    Date_Closed DATE,
    PRIMARY KEY (Customer_ID, Policy_ID),
    FOREIGN KEY (Customer_ID) REFERENCES Customers(Customer_ID),
    FOREIGN KEY (Policy_ID) REFERENCES Available_Policies(Policy_ID)
);

-- Associative Entity: Services_Customer_Policies
CREATE TABLE Services_Customer_Policies (
    Service_ID INT,
    Customer_ID INT,
    Policy_ID INT,
    PRIMARY KEY (Service_ID, Customer_ID, Policy_ID),
    FOREIGN KEY (Service_ID) REFERENCES Services(Service_ID),
    FOREIGN KEY (Customer_ID, Policy_ID) REFERENCES Customers_Policies(Customer_ID, Policy_ID)
);

-- Associative Entity: First_Notification_of_Loss_Customer_Policies
CREATE TABLE First_Notification_of_Loss_Customer_Policies (
    FNOL_ID INT,
    Customer_ID INT,
    Policy_ID INT,
    PRIMARY KEY (FNOL_ID, Customer_ID, Policy_ID),
    FOREIGN KEY (FNOL_ID) REFERENCES First_Notification_of_Loss(FNOL_ID),
    FOREIGN KEY (Customer_ID, Policy_ID) REFERENCES Customers_Policies(Customer_ID, Policy_ID)
);

-- Associative Entity: Claims_FNOL
CREATE TABLE Claims_FNOL (
    Claim_ID INT,
    FNOL_ID INT,
    PRIMARY KEY (Claim_ID, FNOL_ID),
    FOREIGN KEY (Claim_ID) REFERENCES Claims(Claim_ID),
    FOREIGN KEY (FNOL_ID) REFERENCES First_Notification_of_Loss(FNOL_ID)
);

-- Associative Entity: Settlements_Claim
CREATE TABLE Settlements_Claim (
    Settlement_ID INT,
    Claim_ID INT,
    PRIMARY KEY (Settlement_ID, Claim_ID),
    FOREIGN KEY (Settlement_ID) REFERENCES Settlements(Settlement_ID),
    FOREIGN KEY (Claim_ID) REFERENCES Claims(Claim_ID)
);