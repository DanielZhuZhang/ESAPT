CREATE TABLE Customers (
    Customer_ID INT,
    Customer_name VARCHAR(255),
    PRIMARY KEY (Customer_ID)
);

CREATE TABLE Services (
    Service_ID INT,
    Service_name VARCHAR(255),
    PRIMARY KEY (Service_ID)
);

CREATE TABLE Available_Policies (
    Policy_ID INT,
    policy_type_code VARCHAR(255),
    Customer_Phone VARCHAR(20),
    PRIMARY KEY (Policy_ID)
);

CREATE TABLE Customers_Policies (
    Customers_Policies_ID INT,
    Date_Opened DATE,
    Date_Closed DATE,
    Customer_ID INT,
    Policy_ID INT,
    Service_ID INT,
    PRIMARY KEY (Customers_Policies_ID),
    FOREIGN KEY (Customer_ID) REFERENCES Customers (Customer_ID),
    FOREIGN KEY (Policy_ID) REFERENCES Available_Policies (Policy_ID),
    FOREIGN KEY (Service_ID) REFERENCES Services (Service_ID)
);

CREATE TABLE First_Notification_of_Loss (
    FNOL_ID INT,
    PRIMARY KEY (FNOL_ID)
);

CREATE TABLE Customers_Policies_First_Notification_of_Loss (
    Customers_Policies_ID INT,
    FNOL_ID INT,
    PRIMARY KEY (Customers_Policies_ID, FNOL_ID),
    FOREIGN KEY (Customers_Policies_ID) REFERENCES Customers_Policies (Customers_Policies_ID),
    FOREIGN KEY (FNOL_ID) REFERENCES First_Notification_of_Loss (FNOL_ID)
);

CREATE TABLE Claims (
    Claim_ID INT,
    Effective_Date DATE,
    FNOL_ID INT,
    PRIMARY KEY (Claim_ID),
    FOREIGN KEY (FNOL_ID) REFERENCES First_Notification_of_Loss (FNOL_ID)
);

CREATE TABLE Settlements (
    Settlement_ID INT,
    Settlement_Amount NUMERIC(10, 2),
    Effective_Date DATE,
    Claim_ID INT,
    PRIMARY KEY (Settlement_ID),
    FOREIGN KEY (Claim_ID) REFERENCES Claims (Claim_ID)
);