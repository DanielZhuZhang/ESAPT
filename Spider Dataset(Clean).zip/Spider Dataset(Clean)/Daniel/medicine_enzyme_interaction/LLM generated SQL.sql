CREATE TABLE medicine (
    id INT,
    name TEXT,
    Trade_Name TEXT,
    FDA_approved BOOLEAN,
    PRIMARY KEY (id)
);

CREATE TABLE enzyme (
    id INT,
    Porphyria TEXT,
    Product TEXT,
    Location TEXT,
    OMIM TEXT,
    name TEXT,
    Chromosome TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE medicine_enzyme_interaction (
    medicine_id INT NOT NULL,
    enzyme_id INT NOT NULL,
    interaction_type TEXT,
    PRIMARY KEY (medicine_id, enzyme_id),
    FOREIGN KEY (medicine_id) REFERENCES medicine (id) ON DELETE CASCADE,
    FOREIGN KEY (enzyme_id) REFERENCES enzyme (id) ON DELETE CASCADE
);