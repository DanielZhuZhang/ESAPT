CREATE TABLE medicine (
    id VARCHAR(50) NOT NULL,
    Trade_Name VARCHAR(255),
    FDA_approved BOOLEAN,
    name VARCHAR(255),
    PRIMARY KEY (id)
);

CREATE TABLE enzyme (
    id VARCHAR(50) NOT NULL,
    Porphyria VARCHAR(255),
    Product VARCHAR(255),
    Location VARCHAR(255),
    OMIM VARCHAR(255),
    Chromosome VARCHAR(255),
    name VARCHAR(255),
    PRIMARY KEY (id)
);

CREATE TABLE medicine_enzyme_interaction (
    medicine_id VARCHAR(50) NOT NULL,
    enzyme_id VARCHAR(50) NOT NULL,
    interaction_type VARCHAR(255) NOT NULL,
    PRIMARY KEY (medicine_id, enzyme_id, interaction_type),
    FOREIGN KEY (medicine_id) REFERENCES medicine (id) ON DELETE CASCADE,
    FOREIGN KEY (enzyme_id) REFERENCES enzyme (id) ON DELETE CASCADE
);