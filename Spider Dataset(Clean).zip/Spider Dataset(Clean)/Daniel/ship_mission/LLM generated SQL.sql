CREATE TABLE ship (
    Ship_ID INTEGER,
    Name TEXT,
    Type TEXT,
    Nationality TEXT,
    Tonnage INTEGER,
    PRIMARY KEY (Ship_ID)
);

CREATE TABLE mission (
    Mission_ID INTEGER,
    Launched_Year INTEGER,
    Location TEXT,
    Speed_knots INTEGER,
    Code TEXT,
    Fate TEXT,
    Ship_ID INTEGER,
    PRIMARY KEY (Mission_ID),
    FOREIGN KEY (Ship_ID) REFERENCES ship (Ship_ID)
);