CREATE TABLE ship (
    Ship_ID INT,
    Type VARCHAR(255),
    Name VARCHAR(255),
    Nationality VARCHAR(255),
    Tonnage INT,
    PRIMARY KEY (Ship_ID)
);

CREATE TABLE mission (
    Mission_ID INT,
    Launched_Year INT,
    Location VARCHAR(255),
    Speed_knots INT,
    Code VARCHAR(255),
    Fate VARCHAR(255),
    Ship_ID INT,
    PRIMARY KEY (Mission_ID),
    FOREIGN KEY (Ship_ID) REFERENCES ship(Ship_ID)
);