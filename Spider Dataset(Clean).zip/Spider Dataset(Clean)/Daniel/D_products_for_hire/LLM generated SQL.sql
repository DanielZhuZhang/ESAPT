CREATE TABLE Discount_Coupons (
    coupon_id INT,
    coupon_amount NUMERIC(12, 2),
    date_issued DATE,
    PRIMARY KEY (coupon_id)
);

CREATE TABLE Products_for_Hire (
    product_id INT,
    product_name VARCHAR(255),
    product_type_code VARCHAR(50),
    product_description TEXT,
    daily_hire_cost NUMERIC(12, 2),
    PRIMARY KEY (product_id)
);

CREATE TABLE Customers (
    customer_id INT,
    coupon_id INT NOT NULL,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    date_became_customer DATE,
    date_last_hire DATE,
    gender_mf CHAR(1),
    good_or_bad_customer BOOLEAN,
    PRIMARY KEY (customer_id),
    FOREIGN KEY (coupon_id) REFERENCES Discount_Coupons (coupon_id)
);

CREATE TABLE Bookings (
    booking_id INT,
    customer_id INT NOT NULL,
    booking_start_date DATE,
    booking_end_date DATE,
    booking_status_code VARCHAR(50),
    amount_payable NUMERIC(12, 2),
    amount_of_refund NUMERIC(12, 2),
    amount_outstanding NUMERIC(12, 2),
    count_hired INT,
    returned_damaged BOOLEAN,
    PRIMARY KEY (booking_id),
    FOREIGN KEY (customer_id) REFERENCES Customers (customer_id)
);

CREATE TABLE Payments (
    payment_id INT,
    booking_id INT NOT NULL,
    payment_type_code VARCHAR(50),
    amount_paid NUMERIC(12, 2),
    amount_due NUMERIC(12, 2),
    payment_date DATE,
    amount_paid_in_full_yn BOOLEAN,
    PRIMARY KEY (payment_id),
    FOREIGN KEY (booking_id) REFERENCES Bookings (booking_id)
);

CREATE TABLE View_Product_Availability (
    booking_id INT NOT NULL,
    product_id INT NOT NULL,
    status_date DATE NOT NULL,
    available_yn BOOLEAN,
    PRIMARY KEY (booking_id, product_id, status_date),
    FOREIGN KEY (booking_id) REFERENCES Bookings (booking_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Products_for_Hire (product_id) ON DELETE CASCADE
);

CREATE TABLE Products_Booked (
    booking_id INT NOT NULL,
    product_id INT NOT NULL,
    booked_amount NUMERIC(12, 2),
    returned_yn BOOLEAN,
    booked_count INT,
    returned_late_yn BOOLEAN,
    PRIMARY KEY (booking_id, product_id),
    FOREIGN KEY (booking_id) REFERENCES Bookings (booking_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Products_for_Hire (product_id) ON DELETE CASCADE
);