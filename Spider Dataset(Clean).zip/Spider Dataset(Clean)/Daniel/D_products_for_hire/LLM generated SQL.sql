CREATE TABLE Discount_Coupons (
    coupon_id INT,
    coupon_amount DECIMAL(10, 2),
    date_issued DATE,
    PRIMARY KEY(coupon_id)
);

CREATE TABLE Products_for_Hire (
    product_id INT,
    product_name TEXT,
    product_type_code TEXT,
    product_description TEXT,
    daily_hire_cost DECIMAL(10, 2),
    PRIMARY KEY(product_id)
);

CREATE TABLE Customers (
    customer_id INT,
    first_name TEXT,
    last_name TEXT,
    gender_mf CHAR(1),
    date_became_customer DATE,
    date_last_hire DATE,
    good_or_bad_customer TEXT,
    coupon_id INT NOT NULL,
    PRIMARY KEY(customer_id),
    FOREIGN KEY(coupon_id) REFERENCES Discount_Coupons (coupon_id)
);

CREATE TABLE Bookings (
    booking_id INT,
    booking_start_date DATE,
    booking_end_date DATE,
    amount_payable DECIMAL(10, 2),
    amount_of_refund DECIMAL(10, 2),
    amount_outstanding DECIMAL(10, 2),
    booking_status_code TEXT,
    count_hired INT,
    returned_damaged_yn BOOLEAN,
    customer_id INT NOT NULL,
    PRIMARY KEY(booking_id),
    FOREIGN KEY(customer_id) REFERENCES Customers (customer_id)
);

CREATE TABLE Payments (
    payment_id INT,
    payment_type_code TEXT,
    amount_paid DECIMAL(10, 2),
    amount_due DECIMAL(10, 2),
    payment_date DATE,
    amount_paid_in_full_yn BOOLEAN,
    customer_id INT NOT NULL,
    booking_id INT NOT NULL,
    PRIMARY KEY(payment_id),
    FOREIGN KEY(customer_id) REFERENCES Customers (customer_id),
    FOREIGN KEY(booking_id) REFERENCES Bookings (booking_id)
);

CREATE TABLE View_Product_Availability (
    available_yn BOOLEAN,
    status_date DATE,
    booking_id INT NOT NULL,
    product_id INT NOT NULL,
    FOREIGN KEY(booking_id) REFERENCES Bookings (booking_id),
    FOREIGN KEY(product_id) REFERENCES Products_for_Hire (product_id)
);

CREATE TABLE Products_Booked (
    booked_amount DECIMAL(10, 2),
    returned_yn BOOLEAN,
    booked_count INT,
    returned_late_yn BOOLEAN,
    booking_id INT NOT NULL,
    product_id INT NOT NULL,
    FOREIGN KEY(booking_id) REFERENCES Bookings (booking_id),
    FOREIGN KEY(product_id) REFERENCES Products_for_Hire (product_id)
);