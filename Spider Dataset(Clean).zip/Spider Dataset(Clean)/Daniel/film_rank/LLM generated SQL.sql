CREATE TABLE film (
    Film_ID INTEGER,
    Title VARCHAR(255),
    Gross_in_dollar NUMERIC,
    Studio VARCHAR(255),
    Director VARCHAR(255),
    PRIMARY KEY (Film_ID)
);

CREATE TABLE market (
    Market_ID INTEGER,
    Number_cities INTEGER,
    Country VARCHAR(255),
    PRIMARY KEY (Market_ID)
);

CREATE TABLE film_market_estimation (
    Estimation_ID INTEGER,
    Year INTEGER,
    Type VARCHAR(255),
    Low_Estimate NUMERIC,
    High_Estimate NUMERIC,
    Film_ID INTEGER NOT NULL,
    Market_ID INTEGER NOT NULL,
    PRIMARY KEY (Estimation_ID),
    FOREIGN KEY (Film_ID) REFERENCES film (Film_ID),
    FOREIGN KEY (Market_ID) REFERENCES market (Market_ID)
);