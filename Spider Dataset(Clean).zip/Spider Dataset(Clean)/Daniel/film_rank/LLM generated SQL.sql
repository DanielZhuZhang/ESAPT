CREATE TABLE film (
    Film_ID TEXT NOT NULL,
    Title TEXT,
    Gross_in_dollar NUMERIC,
    Studio TEXT,
    Director TEXT,
    PRIMARY KEY (Film_ID)
);

CREATE TABLE market (
    Market_ID TEXT NOT NULL,
    Number_cities INTEGER,
    Country TEXT,
    PRIMARY KEY (Market_ID)
);

CREATE TABLE film_market_estimation (
    Estimation_ID TEXT NOT NULL,
    Type TEXT,
    Year INTEGER,
    High_Estimate NUMERIC,
    Low_Estimate NUMERIC,
    Film_ID TEXT NOT NULL,
    Market_ID TEXT NOT NULL,
    PRIMARY KEY (Estimation_ID),
    FOREIGN KEY (Film_ID) REFERENCES film (Film_ID),
    FOREIGN KEY (Market_ID) REFERENCES market (Market_ID)
);