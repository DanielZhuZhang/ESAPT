CREATE TABLE Addresses (
    address_id TEXT PRIMARY KEY,
    line_1 TEXT,
    line_2 TEXT,
    city TEXT,
    state_province_county TEXT,
    zip_postcode TEXT,
    country TEXT
);

CREATE TABLE People (
    person_id TEXT PRIMARY KEY,
    email_address TEXT,
    cell_mobile_number TEXT,
    password TEXT,
    first_name TEXT,
    middle_name TEXT,
    last_name TEXT,
    login_name TEXT
);

CREATE TABLE Courses (
    course_id TEXT PRIMARY KEY,
    course_name TEXT,
    course_description TEXT,
    other_details TEXT
);

CREATE TABLE Students (
    person_id TEXT NOT NULL,
    student_details TEXT,
    PRIMARY KEY (person_id),
    FOREIGN KEY (person_id) REFERENCES People (person_id) ON DELETE CASCADE
);

CREATE TABLE Candidates (
    person_id TEXT NOT NULL,
    candidate_details TEXT,
    PRIMARY KEY (person_id),
    FOREIGN KEY (person_id) REFERENCES People (person_id) ON DELETE CASCADE
);

CREATE TABLE People_Addresses (
    address_id TEXT NOT NULL,
    person_id TEXT NOT NULL,
    person_address_id TEXT NOT NULL,
    date_from DATE,
    date_to DATE,
    PRIMARY KEY (address_id, person_id, person_address_id),
    FOREIGN KEY (address_id) REFERENCES Addresses (address_id) ON DELETE CASCADE,
    FOREIGN KEY (person_id) REFERENCES People (person_id) ON DELETE CASCADE
);

CREATE TABLE Student_Course_Registrations (
    course_id TEXT NOT NULL,
    person_id TEXT NOT NULL,
    registration_date DATE NOT NULL,
    PRIMARY KEY (course_id, person_id, registration_date),
    FOREIGN KEY (course_id) REFERENCES Courses (course_id) ON DELETE CASCADE,
    FOREIGN KEY (person_id) REFERENCES Students (person_id) ON DELETE CASCADE
);

CREATE TABLE Student_Course_Attendance (
    course_id TEXT NOT NULL,
    person_id TEXT NOT NULL,
    registration_date DATE NOT NULL,
    date_of_attendance DATE NOT NULL,
    PRIMARY KEY (course_id, person_id, registration_date, date_of_attendance),
    FOREIGN KEY (course_id, person_id, registration_date) REFERENCES Student_Course_Registrations (course_id, person_id, registration_date) ON DELETE CASCADE
);

CREATE TABLE Candidate_Assessments (
    person_id TEXT NOT NULL,
    assessment_date DATE,
    assessment_outcome_code TEXT,
    qualification TEXT,
    PRIMARY KEY (person_id),
    FOREIGN KEY (person_id) REFERENCES Candidates (person_id) ON DELETE CASCADE
);