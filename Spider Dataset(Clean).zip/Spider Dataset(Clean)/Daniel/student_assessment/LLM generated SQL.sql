CREATE TABLE People (
    person_id SERIAL,
    email_address TEXT,
    cell_mobile_number TEXT,
    first_name TEXT,
    password TEXT,
    middle_name TEXT,
    last_name TEXT,
    login_name TEXT,
    PRIMARY KEY (person_id)
);

CREATE TABLE Addresses (
    address_id SERIAL,
    country TEXT,
    line_1 TEXT,
    city TEXT,
    zip_postcode TEXT,
    state_province_county TEXT,
    line_2 TEXT,
    PRIMARY KEY (address_id)
);

CREATE TABLE Courses (
    course_id SERIAL,
    course_name TEXT,
    course_description TEXT,
    other_details TEXT,
    PRIMARY KEY (course_id)
);

CREATE TABLE Students (
    person_id INT NOT NULL,
    student_details TEXT,
    PRIMARY KEY (person_id),
    FOREIGN KEY (person_id) REFERENCES People (person_id) ON DELETE CASCADE
);

CREATE TABLE Candidates (
    person_id INT NOT NULL,
    candidate_details TEXT,
    PRIMARY KEY (person_id),
    FOREIGN KEY (person_id) REFERENCES People (person_id) ON DELETE CASCADE
);

CREATE TABLE People_Addresses (
    person_id INT NOT NULL,
    address_id INT NOT NULL,
    person_address_id INT NOT NULL,
    date_to DATE,
    date_from DATE,
    PRIMARY KEY (person_id, address_id, person_address_id),
    FOREIGN KEY (person_id) REFERENCES People (person_id) ON DELETE CASCADE,
    FOREIGN KEY (address_id) REFERENCES Addresses (address_id) ON DELETE CASCADE
);

CREATE TABLE Student_Course_Registrations (
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    registration_date DATE,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES Students (person_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES Courses (course_id) ON DELETE CASCADE
);

CREATE TABLE Candidate_Assessments (
    person_id INT NOT NULL,
    assessment_date DATE,
    assessment_outcome_code TEXT,
    qualification TEXT,
    PRIMARY KEY (person_id),
    FOREIGN KEY (person_id) REFERENCES Candidates (person_id) ON DELETE CASCADE
);

CREATE TABLE Student_Course_Attendance (
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    date_of_attendance DATE,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id, course_id) REFERENCES Student_Course_Registrations (student_id, course_id) ON DELETE CASCADE
);