CREATE TABLE Problem_Status_Codes (
    problem_status_code INTEGER,
    problem_status_description VARCHAR(255),
    PRIMARY KEY (problem_status_code)
);

CREATE TABLE Problem_Category_Codes (
    problem_category_code INTEGER,
    problem_category_description VARCHAR(255),
    PRIMARY KEY (problem_category_code)
);

CREATE TABLE Staff (
    staff_id INTEGER,
    staff_first_name VARCHAR(255),
    staff_last_name VARCHAR(255),
    other_staff_details VARCHAR(255),
    PRIMARY KEY (staff_id)
);

CREATE TABLE Product (
    product_id INTEGER,
    product_name VARCHAR(255),
    product_details VARCHAR(255),
    PRIMARY KEY (product_id)
);

CREATE TABLE Problems (
    problem_id INTEGER,
    date_problem_reported DATE,
    problem_description VARCHAR(255),
    date_problem_closed DATE,
    other_problem_details VARCHAR(255),
    reported_by_staff_id INTEGER,
    closure_authorised_by_staff_id INTEGER,
    product_product_id INTEGER,
    PRIMARY KEY (problem_id),
    FOREIGN KEY (reported_by_staff_id) REFERENCES Staff (staff_id),
    FOREIGN KEY (closure_authorised_by_staff_id) REFERENCES Staff (staff_id),
    FOREIGN KEY (product_product_id) REFERENCES Product (product_id)
);

CREATE TABLE Problem_Log (
    problem_log_id INTEGER,
    log_entry_fix VARCHAR(255),
    log_entry_description VARCHAR(255),
    other_log_details VARCHAR(255),
    log_entry_date DATE,
    problem_status_code INTEGER,
    problem_category_code INTEGER,
    assigned_to_staff_id INTEGER,
    problems_problem_id INTEGER,
    PRIMARY KEY (problem_log_id),
    FOREIGN KEY (problem_status_code) REFERENCES Problem_Status_Codes (problem_status_code),
    FOREIGN KEY (problem_category_code) REFERENCES Problem_Category_Codes (problem_category_code),
    FOREIGN KEY (assigned_to_staff_id) REFERENCES Staff (staff_id),
    FOREIGN KEY (problems_problem_id) REFERENCES Problems (problem_id)
);