CREATE TABLE Problem_Status_Codes (
    problem_status_code TEXT NOT NULL,
    problem_status_description TEXT,
    PRIMARY KEY (problem_status_code)
);

CREATE TABLE Problem_Category_Codes (
    problem_category_code TEXT NOT NULL,
    problem_category_description TEXT,
    PRIMARY KEY (problem_category_code)
);

CREATE TABLE Staff (
    staff_id BIGINT NOT NULL,
    staff_first_name TEXT,
    staff_last_name TEXT,
    other_staff_details TEXT,
    PRIMARY KEY (staff_id)
);

CREATE TABLE Product (
    product_id BIGINT NOT NULL,
    product_name TEXT,
    product_details TEXT,
    PRIMARY KEY (product_id)
);

CREATE TABLE Problems (
    problem_id BIGINT NOT NULL,
    problem_description TEXT,
    date_problem_reported DATE,
    date_problem_closed DATE,
    other_problem_details TEXT,
    product_id BIGINT,
    reported_by_staff_id BIGINT,
    closure_authorised_by_staff_id BIGINT,
    PRIMARY KEY (problem_id),
    FOREIGN KEY (product_id) REFERENCES Product (product_id),
    FOREIGN KEY (reported_by_staff_id) REFERENCES Staff (staff_id),
    FOREIGN KEY (closure_authorised_by_staff_id) REFERENCES Staff (staff_id)
);

CREATE TABLE Problem_Log (
    problem_log_id BIGINT NOT NULL,
    log_entry_date DATE,
    log_entry_description TEXT,
    log_entry_fix TEXT,
    other_log_details TEXT,
    problem_status_code TEXT,
    problem_category_code TEXT,
    assigned_to_staff_id BIGINT,
    problem_id BIGINT,
    PRIMARY KEY (problem_log_id),
    FOREIGN KEY (problem_status_code) REFERENCES Problem_Status_Codes (problem_status_code),
    FOREIGN KEY (problem_category_code) REFERENCES Problem_Category_Codes (problem_category_code),
    FOREIGN KEY (assigned_to_staff_id) REFERENCES Staff (staff_id),
    FOREIGN KEY (problem_id) REFERENCES Problems (problem_id)
);