CREATE TABLE building (
    building_id VARCHAR(50),
    Name VARCHAR(255),
    Floors INT,
    Height_feet INT,
    Years_as_tallest INT,
    Street_address VARCHAR(255),
    PRIMARY KEY (building_id)
);

CREATE TABLE Institution (
    Institution_id VARCHAR(50),
    Type VARCHAR(255),
    Location VARCHAR(255),
    Founded INT,
    Institution VARCHAR(255),
    Primary_Conference VARCHAR(255),
    Enrollment INT,
    Team VARCHAR(255),
    building_id VARCHAR(50),
    PRIMARY KEY (Institution_id),
    FOREIGN KEY (building_id) REFERENCES building (building_id)
);

CREATE TABLE protein (
    protein_name VARCHAR(255),
    common_name VARCHAR(255),
    sequence_length INT,
    accession_number VARCHAR(255),
    sequence_identity_to_human_protein NUMERIC(5,3),
    divergence_from_human_lineage NUMERIC(5,3),
    Institution_id VARCHAR(50),
    PRIMARY KEY (protein_name),
    FOREIGN KEY (Institution_id) REFERENCES Institution (Institution_id)
);