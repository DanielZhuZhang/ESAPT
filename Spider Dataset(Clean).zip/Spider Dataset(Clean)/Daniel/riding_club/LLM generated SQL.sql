CREATE TABLE player (
    Player_ID INT NOT NULL,
    Sponsor_name VARCHAR(255),
    Player_name VARCHAR(255),
    Gender VARCHAR(10),
    Residence VARCHAR(255),
    Occupation VARCHAR(255),
    Votes INT,
    Rank INT,
    PRIMARY KEY (Player_ID)
);

CREATE TABLE club (
    Club_ID INT NOT NULL,
    Club_name VARCHAR(255),
    Region VARCHAR(255),
    Start_year INT,
    PRIMARY KEY (Club_ID)
);

CREATE TABLE coach (
    Coach_ID INT NOT NULL,
    Coach_name VARCHAR(255),
    Gender VARCHAR(10),
    Rank INT,
    PRIMARY KEY (Coach_ID)
);

CREATE TABLE player_coach (
    Player_ID INT NOT NULL,
    Coach_ID INT NOT NULL,
    Starting_year INT,
    PRIMARY KEY (Player_ID, Coach_ID),
    FOREIGN KEY (Player_ID) REFERENCES player (Player_ID),
    FOREIGN KEY (Coach_ID) REFERENCES coach (Coach_ID)
);

CREATE TABLE match_result (
    Match_Result_ID INT NOT NULL,
    Club_ID INT NOT NULL,
    Rank INT,
    Gold INT,
    Big_Silver INT,
    Small_Silver INT,
    Bronze INT,
    Points INT,
    Player_ID INT,
    Coach_ID INT,
    PRIMARY KEY (Club_ID, Match_Result_ID),
    FOREIGN KEY (Club_ID) REFERENCES club (Club_ID) ON DELETE CASCADE,
    FOREIGN KEY (Player_ID) REFERENCES player (Player_ID),
    FOREIGN KEY (Coach_ID) REFERENCES coach (Coach_ID)
);

CREATE TABLE player_coach_match_result (
    Player_ID INT NOT NULL,
    Coach_ID INT NOT NULL,
    Club_ID INT NOT NULL,
    Match_Result_ID INT NOT NULL,
    PRIMARY KEY (Player_ID, Coach_ID, Club_ID, Match_Result_ID),
    FOREIGN KEY (Player_ID, Coach_ID) REFERENCES player_coach (Player_ID, Coach_ID),
    FOREIGN KEY (Club_ID, Match_Result_ID) REFERENCES match_result (Club_ID, Match_Result_ID)
);