CREATE TABLE player (
    Player_ID INT,
    Sponsor_name VARCHAR(255),
    Player_name VARCHAR(255),
    Gender CHAR(1),
    Residence VARCHAR(255),
    Occupation VARCHAR(255),
    Votes INT,
    Rank INT,
    PRIMARY KEY (Player_ID)
);

CREATE TABLE club (
    Club_ID INT,
    Club_name VARCHAR(255),
    Region VARCHAR(255),
    Start_year INT,
    PRIMARY KEY (Club_ID)
);

CREATE TABLE coach (
    Coach_ID INT,
    Coach_name VARCHAR(255),
    Gender CHAR(1),
    Rank INT,
    PRIMARY KEY (Coach_ID)
);

CREATE TABLE match_result (
    Club_ID INT NOT NULL,
    Rank INT NOT NULL,
    Gold INT,
    Big_Silver INT,
    Small_Silver INT,
    Bronze INT,
    Points INT,
    PRIMARY KEY (Club_ID, Rank),
    FOREIGN KEY (Club_ID) REFERENCES club(Club_ID) ON DELETE CASCADE
);

CREATE TABLE player_coach (
    Player_ID INT NOT NULL,
    Coach_ID INT NOT NULL,
    Starting_year INT,
    match_result_Club_ID INT NOT NULL,
    match_result_Rank INT NOT NULL,
    PRIMARY KEY (Player_ID, Coach_ID),
    FOREIGN KEY (Player_ID) REFERENCES player(Player_ID),
    FOREIGN KEY (Coach_ID) REFERENCES coach(Coach_ID),
    FOREIGN KEY (match_result_Club_ID, match_result_Rank) REFERENCES match_result(Club_ID, Rank)
);