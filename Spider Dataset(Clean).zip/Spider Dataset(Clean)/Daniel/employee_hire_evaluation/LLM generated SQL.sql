CREATE TABLE shop (
    Shop_ID INT PRIMARY KEY,
    Location VARCHAR(255),
    District VARCHAR(255),
    Name VARCHAR(255),
    Manager_name VARCHAR(255),
    Number_products INT
);

CREATE TABLE hiring (
    Start_from DATE NOT NULL,
    Is_full_time BOOLEAN,
    shop_Shop_ID INT NOT NULL,
    PRIMARY KEY(shop_Shop_ID, Start_from),
    FOREIGN KEY (shop_Shop_ID) REFERENCES shop(Shop_ID) ON DELETE CASCADE
);

CREATE TABLE employee (
    Employee_ID INT PRIMARY KEY,
    Name VARCHAR(255),
    City VARCHAR(255),
    Age INT
);

CREATE TABLE evaluation (
    Year_awarded INT NOT NULL,
    Bonus DECIMAL,
    employee_Employee_ID INT NOT NULL,
    PRIMARY KEY(employee_Employee_ID, Year_awarded),
    FOREIGN KEY (employee_Employee_ID) REFERENCES employee(Employee_ID) ON DELETE CASCADE
);