CREATE TABLE shop (
    Shop_ID INTEGER PRIMARY KEY,
    Location VARCHAR(255),
    District VARCHAR(255),
    Name VARCHAR(255),
    Manager_name VARCHAR(255),
    Number_products INTEGER
);

CREATE TABLE employee (
    Employee_ID INTEGER PRIMARY KEY,
    Name VARCHAR(255),
    City VARCHAR(255),
    Age INTEGER
);

CREATE TABLE hiring (
    Shop_ID INTEGER NOT NULL,
    Start_from DATE NOT NULL,
    Is_full_time BOOLEAN NOT NULL,
    PRIMARY KEY (Shop_ID, Start_from, Is_full_time),
    FOREIGN KEY (Shop_ID) REFERENCES shop (Shop_ID) ON DELETE CASCADE
);

CREATE TABLE evaluation (
    Employee_ID INTEGER NOT NULL,
    Year_awarded INTEGER NOT NULL,
    Bonus NUMERIC(10, 2),
    PRIMARY KEY (Employee_ID, Year_awarded),
    FOREIGN KEY (Employee_ID) REFERENCES employee (Employee_ID) ON DELETE CASCADE
);