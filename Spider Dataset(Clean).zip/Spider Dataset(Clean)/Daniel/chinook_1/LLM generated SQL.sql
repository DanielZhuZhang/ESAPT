Here is the information extracted from the provided ER diagram:

**Entities and their Attributes:**

1.  **Album**
    *   AlbumId (Primary Key)
    *   Title

2.  **Artist**
    *   ArtistId (Primary Key)
    *   Name

3.  **Customer**
    *   CustomerId (Primary Key)
    *   FirstName
    *   LastName
    *   Company
    *   Address
    *   City
    *   State
    *   Country
    *   PostalCode
    *   Phone
    *   Fax
    *   Email

4.  **Employee**
    *   EmployeeId (Primary Key)
    *   LastName
    *   FirstName
    *   Title
    *   BirthDate
    *   HireDate
    *   Address
    *   City
    *   State
    *   Country
    *   PostalCode
    *   Phone
    *   Fax
    *   Email

5.  **Genre**
    *   GenreId (Primary Key)
    *   Name

6.  **Invoice**
    *   InvoiceId (Primary Key)
    *   InvoiceDate
    *   BillingAddress
    *   BillingCity
    *   BillingState
    *   BillingCountry
    *   BillingPostalCode
    *   Total

7.  **InvoiceLine**
    *   InvoiceLineId (Primary Key)
    *   UnitPrice
    *   Quantity

8.  **MediaType**
    *   MediaTypeId (Primary Key)
    *   Name

9.  **Playlist**
    *   PlaylistId (Primary Key)
    *   Name

10. **PlaylistTrack** (Junction Entity / Weak Entity)
    *   (Implied composite primary key from PlaylistId and TrackId)

11. **Track**
    *   TrackId (Primary Key)
    *   Name
    *   Composer
    *   Milliseconds
    *   Bytes
    *   UnitPrice

**Relationships and Cardinalities:**

*   **Album** --(Album.ArtistId -> Artist.ArtistId (N:1))-- **Artist**
    *   An Artist can have N Albums.
    *   An Album belongs to 1 Artist.

*   **Customer** --(Customer.SupportRepId -> Employee.EmployeeId (N:1))-- **Employee**
    *   An Employee can support N Customers.
    *   A Customer is supported by 1 Employee.

*   **Employee** --(Employee.ReportsTo -> Employee.EmployeeId (N:1))-- **Employee** (Self-referencing relationship)
    *   An Employee can report to 1 other Employee.
    *   An Employee can have N employees reporting to them.

*   **Invoice** --(Invoice.CustomerId -> Customer.CustomerId (N:1))-- **Customer**
    *   A Customer can have N Invoices.
    *   An Invoice belongs to 1 Customer.

*   **InvoiceLine** --(InvoiceLine.InvoiceId -> Invoice.InvoiceId (N:1))-- **Invoice**
    *   An Invoice can have N InvoiceLines.
    *   An InvoiceLine belongs to 1 Invoice.

*   **InvoiceLine** --(InvoiceLine.TrackId -> Track.TrackId (N:1))-- **Track**
    *   A Track can be included in N InvoiceLines.
    *   An InvoiceLine refers to 1 Track.

*   **PlaylistTrack** --(PlaylistTrack.TrackId -> Track.TrackId (1:1))-- **Track**
    *   A Track can be in 1 PlaylistTrack entry (representing its inclusion in a playlist).
    *   A PlaylistTrack entry refers to 1 Track.
    *(Note: The diagram indicates (1:1) but typically in a many-to-many relationship like PlaylistTrack, Track could appear in multiple PlaylistTrack entries for different playlists. This might be interpreted as a single instance of a Track in a single instance of PlaylistTrack within a given playlist context or a specific mapping within the junction table.)*

*   **PlaylistTrack** --(PlaylistTrack.PlaylistId -> Playlist.PlaylistId (1:1))-- **Playlist**
    *   A Playlist can have 1 PlaylistTrack entry (representing one track in that playlist).
    *   A PlaylistTrack entry refers to 1 Playlist.
    *(Similar note as above, the (1:1) might be specific to how the junction table is conceptualized, but playlists generally have many tracks, and tracks can be in many playlists, suggesting a many-to-many relationship that PlaylistTrack resolves.)*

*   **Track** --(Track.AlbumId -> Album.AlbumId (N:1))-- **Album**
    *   An Album can have N Tracks.
    *   A Track belongs to 1 Album.

*   **Track** --(Track.GenreId -> Genre.GenreId (N:1))-- **Genre**
    *   A Genre can have N Tracks.
    *   A Track belongs to 1 Genre.

*   **Track** --(Track.MediaTypeId -> MediaType.MediaTypeId (N:1))-- **MediaType**
    *   A MediaType can be used for N Tracks.
    *   A Track has 1 MediaType.