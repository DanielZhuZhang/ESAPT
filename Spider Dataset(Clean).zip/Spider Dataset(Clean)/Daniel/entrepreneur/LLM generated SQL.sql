CREATE TABLE people (
    People_ID INTEGER,
    Height NUMERIC,
    Weight NUMERIC,
    Name VARCHAR(255),
    Date_of_Birth DATE,
    PRIMARY KEY (People_ID)
);

CREATE TABLE entrepreneur (
    Entrepreneur_ID INTEGER,
    Money_Requested NUMERIC,
    Company VARCHAR(255),
    Investor VARCHAR(255),
    People_ID INTEGER,
    PRIMARY KEY (Entrepreneur_ID),
    FOREIGN KEY (People_ID) REFERENCES people (People_ID)
);