CREATE TABLE people (
    People_ID INT,
    Height NUMERIC,
    Weight NUMERIC,
    Name TEXT,
    Date_of_Birth DATE,
    PRIMARY KEY (People_ID)
);

CREATE TABLE entrepreneur (
    Entrepreneur_ID INT,
    Money_Requested NUMERIC,
    Company TEXT,
    Investor TEXT,
    People_ID INT,
    PRIMARY KEY (Entrepreneur_ID),
    FOREIGN KEY (People_ID) REFERENCES people (People_ID)
);