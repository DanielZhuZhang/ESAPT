CREATE TABLE Apartment_Buildings (
    building_id INTEGER,
    building_full_name TEXT,
    building_short_name TEXT,
    building_address TEXT,
    building_phone TEXT,
    building_manager TEXT,
    building_description TEXT,
    PRIMARY KEY (building_id)
);

CREATE TABLE Apartments (
    apt_id INTEGER,
    apt_type_code TEXT,
    apt_number INTEGER,
    bedroom_count INTEGER,
    bathroom_count INTEGER,
    room_count INTEGER,
    building_id INTEGER,
    PRIMARY KEY (apt_id),
    FOREIGN KEY (building_id) REFERENCES Apartment_Buildings (building_id)
);

CREATE TABLE Guests (
    guest_id INTEGER,
    guest_first_name TEXT,
    guest_last_name TEXT,
    date_of_birth DATE,
    gender_code TEXT,
    PRIMARY KEY (guest_id)
);

CREATE TABLE Apartment_Facilities (
    facility_code TEXT,
    apt_id INTEGER NOT NULL,
    PRIMARY KEY (apt_id, facility_code),
    FOREIGN KEY (apt_id) REFERENCES Apartments (apt_id) ON DELETE CASCADE
);

CREATE TABLE Apartment_Bookings (
    apt_booking_id INTEGER,
    booking_start_date DATE,
    booking_end_date DATE,
    booking_status_code TEXT,
    apt_id INTEGER,
    guest_id INTEGER,
    PRIMARY KEY (apt_booking_id),
    FOREIGN KEY (apt_id) REFERENCES Apartments (apt_id),
    FOREIGN KEY (guest_id) REFERENCES Guests (guest_id)
);

CREATE TABLE View_Unit_Status (
    status_date DATE,
    available_yn TEXT,
    apt_booking_id INTEGER NOT NULL,
    apt_id INTEGER,
    PRIMARY KEY (apt_booking_id, status_date),
    FOREIGN KEY (apt_booking_id) REFERENCES Apartment_Bookings (apt_booking_id) ON DELETE CASCADE,
    FOREIGN KEY (apt_id) REFERENCES Apartments (apt_id)
);