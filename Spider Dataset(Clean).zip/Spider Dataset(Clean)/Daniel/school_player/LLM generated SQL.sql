CREATE TABLE school (
    School_ID INTEGER,
    School VARCHAR(255),
    Location VARCHAR(255),
    Denomination VARCHAR(255),
    Enrollment INTEGER,
    Founded INTEGER,
    School_Colors VARCHAR(255),
    Boys_or_Girls VARCHAR(255),
    Day_or_Boarding VARCHAR(255),
    PRIMARY KEY (School_ID)
);

CREATE TABLE school_details (
    details_id INTEGER,
    school_School_ID INTEGER NOT NULL,
    League VARCHAR(255),
    Nickname VARCHAR(255),
    Division VARCHAR(255),
    Colors VARCHAR(255),
    Class VARCHAR(255),
    PRIMARY KEY (school_School_ID, details_id),
    FOREIGN KEY (school_School_ID) REFERENCES school(School_ID) ON DELETE CASCADE
);

CREATE TABLE school_performance (
    school_School_ID INTEGER NOT NULL,
    School_Year INTEGER,
    Year_Entered_Competition INTEGER,
    Class_AA VARCHAR(255),
    Class_A VARCHAR(255),
    PRIMARY KEY (school_School_ID, School_Year),
    FOREIGN KEY (school_School_ID) REFERENCES school(School_ID) ON DELETE CASCADE
);

CREATE TABLE player (
    Player_ID INTEGER,
    school_School_ID INTEGER,
    Player VARCHAR(255),
    Position VARCHAR(255),
    Team VARCHAR(255),
    Age INTEGER,
    PRIMARY KEY (Player_ID),
    FOREIGN KEY (school_School_ID) REFERENCES school(School_ID)
);