CREATE TABLE shop (
    Shop_ID INTEGER,
    Address TEXT,
    Score INTEGER,
    Num_of_staff INTEGER,
    Open_Year INTEGER,
    PRIMARY KEY (Shop_ID)
);

CREATE TABLE happy_hour (
    Shop_ID INTEGER NOT NULL,
    HH_ID INTEGER NOT NULL,
    Month INTEGER,
    Num_of_staff_in_charge INTEGER,
    PRIMARY KEY (Shop_ID, HH_ID),
    FOREIGN KEY (Shop_ID) REFERENCES shop (Shop_ID) ON DELETE CASCADE
);

CREATE TABLE member (
    Member_ID INTEGER,
    Name TEXT,
    Address TEXT,
    Age INTEGER,
    Membership_card TEXT,
    Level_of_membership TEXT,
    Time_of_purchase TIMESTAMP,
    PRIMARY KEY (Member_ID)
);

CREATE TABLE happy_hour_member (
    Member_ID INTEGER NOT NULL,
    HH_ID INTEGER NOT NULL,
    Total_amount DECIMAL,
    PRIMARY KEY (Member_ID, HH_ID),
    FOREIGN KEY (Member_ID) REFERENCES member (Member_ID) ON DELETE CASCADE
);