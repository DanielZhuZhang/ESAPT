CREATE TABLE shop (
    Shop_ID TEXT,
    Address VARCHAR(255),
    Score INTEGER,
    Num_of_staff INTEGER,
    Open_Year INTEGER,
    PRIMARY KEY(Shop_ID)
);

CREATE TABLE member (
    Member_ID TEXT,
    Address VARCHAR(255),
    Age INTEGER,
    Name VARCHAR(255),
    Membership_card VARCHAR(50),
    PRIMARY KEY(Member_ID)
);

CREATE TABLE happy_hour (
    Shop_ID TEXT NOT NULL,
    HH_ID TEXT,
    Month INTEGER,
    Num_of_shaff_in_charge INTEGER,
    PRIMARY KEY(Shop_ID, HH_ID),
    FOREIGN KEY(Shop_ID) REFERENCES shop(Shop_ID) ON DELETE CASCADE
);

CREATE TABLE happy_hour_member (
    Member_ID TEXT NOT NULL,
    HH_ID TEXT,
    Total_amount NUMERIC(10,2),
    Time_of_purchase TIMESTAMP,
    Level_of_membership VARCHAR(50),
    PRIMARY KEY(Member_ID, HH_ID),
    FOREIGN KEY(Member_ID) REFERENCES member(Member_ID) ON DELETE CASCADE
);