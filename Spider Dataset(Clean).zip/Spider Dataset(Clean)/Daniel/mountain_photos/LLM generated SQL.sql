CREATE TABLE camera_lens (
    id INTEGER,
    brand VARCHAR(255),
    max_aperture NUMERIC,
    name VARCHAR(255),
    focal_length_mm INTEGER,
    PRIMARY KEY (id)
);

CREATE TABLE mountain (
    id INTEGER,
    Country VARCHAR(255),
    Prominence NUMERIC,
    name VARCHAR(255),
    Height NUMERIC,
    Range VARCHAR(255),
    PRIMARY KEY (id)
);

CREATE TABLE photos (
    id INTEGER,
    name VARCHAR(255),
    color VARCHAR(255),
    camera_lens_id INTEGER,
    mountain_id INTEGER,
    PRIMARY KEY (id),
    FOREIGN KEY (camera_lens_id) REFERENCES camera_lens (id),
    FOREIGN KEY (mountain_id) REFERENCES mountain (id)
);