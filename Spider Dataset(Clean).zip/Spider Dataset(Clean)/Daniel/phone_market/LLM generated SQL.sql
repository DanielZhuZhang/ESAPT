CREATE TABLE market (
    Market_ID TEXT,
    District TEXT,
    Ranking INTEGER,
    Num_of_shops INTEGER,
    Num_of_employees INTEGER,
    PRIMARY KEY (Market_ID)
);

CREATE TABLE phone (
    Phone_ID TEXT,
    Name TEXT,
    Memory_in_G INTEGER,
    Price NUMERIC,
    Carrier TEXT,
    PRIMARY KEY (Phone_ID)
);

CREATE TABLE phone_market (
    Market_ID TEXT NOT NULL,
    Phone_ID TEXT NOT NULL,
    Num_of_stock INTEGER,
    PRIMARY KEY (Market_ID, Phone_ID),
    FOREIGN KEY (Market_ID) REFERENCES market (Market_ID) ON DELETE CASCADE,
    FOREIGN KEY (Phone_ID) REFERENCES phone (Phone_ID) ON DELETE CASCADE
);