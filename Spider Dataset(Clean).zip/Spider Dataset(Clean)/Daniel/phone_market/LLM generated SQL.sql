CREATE TABLE market (
    Market_ID INT,
    District VARCHAR(255),
    Ranking INT,
    Num_of_shops INT,
    Num_of_employees INT,
    PRIMARY KEY (Market_ID)
);

CREATE TABLE phone (
    Phone_ID INT,
    Name VARCHAR(255),
    Memory_in_G INT,
    Price DECIMAL(10, 2),
    Carrier VARCHAR(255),
    PRIMARY KEY (Phone_ID)
);

CREATE TABLE phone_market (
    Market_ID INT NOT NULL,
    Phone_ID INT NOT NULL,
    Num_of_stock INT,
    PRIMARY KEY (Market_ID, Phone_ID),
    FOREIGN KEY (Market_ID) REFERENCES market(Market_ID) ON DELETE CASCADE,
    FOREIGN KEY (Phone_ID) REFERENCES phone(Phone_ID) ON DELETE CASCADE
);